package chap14.java;
import chap11.ArrayEnv;

public class length {
    public static int m(ArrayEnv env, String s) { return m(s); }
    public static int m(String s) { return s.length(); }
}
