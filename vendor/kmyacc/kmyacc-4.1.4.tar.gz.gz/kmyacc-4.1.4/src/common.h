/*
 * common definitions
 *
 * Copyright (C) 1993, 2005  MORI Koichiro
 */


typedef unsigned char uchar;
typedef int bool;

#define YES 1
#define NO 0
#define height(x) (sizeof(x) / sizeof((x)[0]))

#define global
#define private static
