#pragma once

void SetYYIN(const char * filePath);
void CloseYYIN();