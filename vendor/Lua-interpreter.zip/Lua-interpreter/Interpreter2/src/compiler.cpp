#include "compiler.h"

using namespace CUA;

InstrumentList
Compiler::compile(ASTNode *)
{ return InstrumentList(); }